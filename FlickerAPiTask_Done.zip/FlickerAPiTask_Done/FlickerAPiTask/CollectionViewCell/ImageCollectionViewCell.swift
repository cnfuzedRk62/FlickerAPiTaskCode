//
//  ImageCollectionViewCell.swift
//  FlickerAPiTask
//
//  Created by Ravinder on 04/09/19.
//  Copyright © 2019 Ravinder. All rights reserved.
//

import UIKit

class ImageCollectionViewCell: UICollectionViewCell {
    
    @IBOutlet var imageView: UIImageView!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

}
