//
//  ViewController.swift
//  FlickerAPiTask
//
//  Created by Ravinder on 04/09/19.
//  Copyright © 2019 Ravinder. All rights reserved.
//

import UIKit
import SDWebImage

class ViewController: UIViewController {
    @IBOutlet var collectionView: UICollectionView!
    let searchBar = UISearchBar()
    var selectedRows = 2
    var selectedHeight = 3
    var post_Count = 20
    var refreshControlBottom = UIRefreshControl()
    var photos: [FlickrPhoto] = []
    override func viewDidLoad() {
        super.viewDidLoad()
        searchBar.sizeToFit()
        searchBar.delegate = self
        searchBar.placeholder = "Search Images"
        self.navigationController?.navigationBar.topItem?.titleView = searchBar
        let logoutBarButtonItem = UIBarButtonItem(title: "Options", style: .done, target: self, action: #selector(options))
        self.navigationItem.rightBarButtonItem  = logoutBarButtonItem
        self.registerXib()
    }
    
    func registerXib(){
         collectionView!.register(UINib(nibName: "ImageCollectionViewCell", bundle: Bundle.main), forCellWithReuseIdentifier: "ImageCollectionViewCell")
    }
    
    @objc func options(){
        let alert = UIAlertController(title: "Poplify Demo", message: "Please Select an Option", preferredStyle: .actionSheet)
        
        alert.addAction(UIAlertAction(title: "2 Rows", style: .default , handler:{ (UIAlertAction)in
            print("User click Approve button")
            self.selectedRows = 2
            self.selectedHeight = 3
            self.collectionView.reloadData()
        }))
        
        alert.addAction(UIAlertAction(title: "3 Rows", style: .default , handler:{ (UIAlertAction)in
            print("User click Edit button")
            self.selectedRows = 3
            self.selectedHeight = 6
            self.collectionView.reloadData()
        }))
        
        alert.addAction(UIAlertAction(title: "4 Rows", style: .default , handler:{ (UIAlertAction)in
            print("User click Delete button")
            self.selectedRows = 4
            self.selectedHeight = 8
            self.collectionView.reloadData()
        }))
        
        alert.addAction(UIAlertAction(title: "Dismiss", style: .cancel, handler:{ (UIAlertAction)in
            print("User click Dismiss button")
        }))
        
        self.present(alert, animated: true, completion: {
            print("completion block")
        })
    }

}

//MARK:- UICOLLECTION VIEW METHODS

extension ViewController : UICollectionViewDelegate, UICollectionViewDataSource ,UICollectionViewDelegateFlowLayout{
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return photos.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
         let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "ImageCollectionViewCell", for: indexPath) as! ImageCollectionViewCell
            cell.imageView.sd_setImage(with: photos[indexPath.row].photoUrl as URL, completed: nil)
            return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        
        var collectionViewSize = collectionView.frame.size
        let prefferedWidth = ((view.bounds.width - CGFloat((selectedRows) * 8))) //for 2 row edit or whatever row you want
        let mainWidth = prefferedWidth/CGFloat(selectedRows)
        collectionViewSize.width = mainWidth//Display Three elements in a row.
        let innerMethod = (view.bounds.height - CGFloat(4 * 8))
        collectionViewSize.height = innerMethod/CGFloat(selectedHeight)  //collectionViewSize.height/4.0
        return collectionViewSize
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumInteritemSpacingForSectionAt section: Int) -> CGFloat {
        return 10.0
    }
    
    func collectionView(_ collectionView: UICollectionView, willDisplay cell: UICollectionViewCell, forItemAt indexPath: IndexPath) {
        if (indexPath.row == photos.count - 1 ) { //it's your last cell
            //Load more data & reload your collection view
            //refreshControlAPI()
            post_Count += 20
            performSearchWithText(searchText: searchBar.text!, pageCount: post_Count)
            print("last part")
        }
    }
 
    
  // Flicker Api
 
    private func performSearchWithText(searchText: String , pageCount : Int) {
        UIApplication.shared.isNetworkActivityIndicatorVisible = true
        FlickrProvider.fetchPhotosForSearchText(searchText: searchText, page: pageCount, onCompletion: { (error: NSError?, flickrPhotos: [FlickrPhoto]?) -> Void in
            DispatchQueue.main.async {
                 UIApplication.shared.isNetworkActivityIndicatorVisible = false
            }
            if error == nil {
                     self.photos = flickrPhotos!
            } else {
                self.photos = []
                if (error!.code == FlickrProvider.Errors.invalidAccessErrorCode) {
                    DispatchQueue.main.async(execute: { () -> Void in
                        self.showErrorAlert()
                    })
                }
            }
            DispatchQueue.main.async(execute: { () -> Void in
                self.title = searchText
                self.collectionView.delegate = self
                self.collectionView.dataSource = self
                self.collectionView.reloadData()
            })
        })
    }
    
    private func showErrorAlert() {
        let alertController = UIAlertController(title: "Search Error", message: "Invalid API Key", preferredStyle: .alert)
        let dismissAction = UIAlertAction(title: "Dismiss", style: .default, handler: nil)
        alertController.addAction(dismissAction)
        self.present(alertController, animated: true, completion: nil)
    }
    
    
    func searchBarSearchButtonClicked(_ searchBar: UISearchBar) {
        searchBar.resignFirstResponder()
        performSearchWithText(searchText: searchBar.text!, pageCount: post_Count)
    }

 
}

extension ViewController : UISearchControllerDelegate, UISearchBarDelegate {
    
    func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String) {
        if Reachability.isConnectedToNetwork() == true {
            print("Hello\(searchBar.text!)")
            performSearchWithText(searchText: searchBar.text!, pageCount: post_Count)
        } else {
            let alertController = UIAlertController(title: "Internet Error", message: "Check your internetConnection.", preferredStyle: .alert)
            let dismissAction = UIAlertAction(title: "Dismiss", style: .default, handler: nil)
            alertController.addAction(dismissAction)
            self.present(alertController, animated: true, completion: nil)
        }
    }
    
    
}
